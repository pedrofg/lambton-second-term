<?php
    require_once('util/secure_conn.php');  // require a secure connection
    require_once('util/valid_admin.php');  // require a valid admin user
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>My Guitar Shop</title>
        <link rel="stylesheet" type="text/css" href="main.css"/>
    </head>
    <body>
        <div id="page">
            <div id="header">
                <h1>My Guitar Shop</h1>
            </div>
            <div id="main">
                <h1>Admin Menu</h1>
                <p><a href="index.php?action=show_product_manager">Product Manager</a></p>
                <p><a href="index.php?action=show_order_manager">Order Manager</a></p>
                <p><a href="index.php?action=logout">Logout</a></p>

            </div><!-- end main -->
        </div><!-- end page -->
    </body>
</html>
