<?php  include '../../util/main.php'; ?>
<?php include '../../view/header.php'; ?>
<div id="content">
    <h1>Category Manager - under construction</h1>
</div>
<?php include '../../view/footer.php'; ?>
