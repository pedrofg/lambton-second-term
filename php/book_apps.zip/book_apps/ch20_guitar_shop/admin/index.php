<?php  include '../util/main.php'; ?>
<?php  include '../view/header.php'; ?>
<div id="content">
    <h1>Admin Menu</h1>
    <p><a href="product">Product Manager</a></p>
    <p><a href="category">Category Manager</a></p>
    <p><a href="order">Order Manager</a></p>
</div>
<?php include '../view/footer.php'; ?>
