//
//  ViewController.swift
//  LearnPods
//
//  Created by Yao Lu on 2017-05-29.
//  Copyright © 2017 Yao Lu. All rights reserved.
//

import UIKit
import EasyPeasy

class ViewController: UIViewController, UserSelectable {
    

    @IBOutlet weak var contentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let tableView = SimpleTableView(frame: self.view.frame)
        tableView.delegate = self
        contentView.addSubview(tableView)
        
        self.title = "Users"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func didUserSelect(_ id: String) {
        print(id)
        let userDetailsController = self.storyboard!.instantiateViewController(withIdentifier: "UserDetailsController") as! UserDetailsController
        userDetailsController.userId = id
        navigationController?.pushViewController(userDetailsController, animated: true)
    }

}


protocol UserSelectable: class {
    
    func didUserSelect(_ id: String)
}



