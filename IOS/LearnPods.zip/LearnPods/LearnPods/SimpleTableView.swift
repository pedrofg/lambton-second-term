//
//  SimpleTableView.swift
//  LearnPods
//
//  Created by MacStudent on 2017-05-31.
//  Copyright © 2017 Yao Lu. All rights reserved.
//

import UIKit
import Kingfisher
import Alamofire
import SwiftyJSON
import SVProgressHUD
import ObjectMapper
import CoreData

class SimpleTableView: UIView, UITableViewDataSource, UITableViewDelegate {
    var baseTableView : UITableView!
    //var swiftyJsonVar :JSON!
    var userInfoArray: Array<UserInfo> = []
    weak var delegate: UserSelectable?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        SVProgressHUD.show(withStatus: "Loading...")
        SVProgressHUD.setDefaultMaskType(.black)
        loadFromDB()
        
        if self.userInfoArray.count == 0 {
            sendRequest()
        } else {
            self.addTableView()
            baseTableView.reloadData()
        }
        
    }
    
    func loadFromDB() {
        do {
            
            let users: [User] = try context.fetch(User.fetchRequest())
            
            for user in users {
                let userInfo = UserInfo(id: user.id!, displayName: user.displayName!, signature: user.signature!, birthday: user.birthday!, mainImage: user.mainImage!)
                userInfoArray.append(userInfo!);
            }
        }
        catch {
            print("Fetching Failed")
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func sendRequest() {
        Alamofire.request("http://eadate.com/api/userInfo")
            .responseJSON { (responseData) -> Void in
                
                
                guard let responseJSON = responseData.result.value as? [String: Any],
                    let results = responseJSON["data"] as? [[String: Any]]
                    else {
                        return
                }
                
                
                self.userInfoArray = Mapper<UserInfo>().mapArray(JSONArray: results )
                
                self.saveInDB();
                
                if self.userInfoArray.count > 0 {
                    self.addTableView()
                }

        }

    }
    
    func saveInDB() {
        for userInfo in self.userInfoArray {
            
            let userCoreData = User(context: self.context)
            userCoreData.displayName = userInfo.displayName
            userCoreData.id = userInfo.id
            userCoreData.signature = userInfo.signature
            userCoreData.birthday = userInfo.birthday
            userCoreData.mainImage = userInfo.mainImage
            
            // Save the data to coredata
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        }

    }
    
    func addTableView() {
        SVProgressHUD.dismiss()
        baseTableView = UITableView(frame: self.frame, style: .plain)
        baseTableView.delegate = self
        baseTableView.dataSource = self
        baseTableView.register(SimpleTableViewCell.self, forCellReuseIdentifier:"SimpleTableViewCell")
        baseTableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0); //values
        self.addSubview(baseTableView)
        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.userInfoArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SimpleTableViewCell", for: indexPath) as! SimpleTableViewCell
    
        let rowNumber = (indexPath as NSIndexPath).row
        
        let userInfo = self.userInfoArray[rowNumber]
        cell.firstLineLabel.text = userInfo.displayName
        cell.secondLineLabel.text = userInfo.signature
        cell.thirdLineLabel.text = userInfo.birthday
        
        cell.mainImageView.image = nil
        cell.mainImageView.layer.cornerRadius = 40
        let mainImage = userInfo.mainImage
        let mainImageUrl = "http://eadate.com/images/user/" + mainImage! + "_size_80.png"
        let url = URL(string: mainImageUrl)
        cell.mainImageView.kf.setImage(with: url, completionHandler: nil)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let userInfo = self.userInfoArray[indexPath.row]
        
        delegate?.didUserSelect(userInfo.id!)
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }

}


