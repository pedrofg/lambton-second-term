//
//  UserDetailBasicCell.swift
//  LearnPods
//
//  Created by Pedro Guimarães fernandes on 2017-11-19.
//  Copyright © 2017 Yao Lu. All rights reserved.
//

import UIKit

class UserDetailBasicCell: UICollectionViewCell {

    @IBOutlet weak var lbObject: UILabel!
    @IBOutlet weak var lbValue: UILabel!
    @IBOutlet weak var imgPicture: UIImageView!
}
