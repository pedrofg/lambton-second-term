
import UIKit
import EasyPeasy
import UIKit
import Kingfisher
import Alamofire
import SwiftyJSON
import SVProgressHUD
import ObjectMapper
import CoreData

class UserDetailsController: UIViewController, UICollectionViewDataSource,UICollectionViewDelegate  {
    
    var userId : String!
    var userDetail : UserDetail!;
    var sportsArr : [String] = [];
    var tagsArr : [String] = [];
    
    @IBOutlet weak var imgMainImage: UIImageView!
    @IBOutlet weak var collectionViewBasics: UICollectionView!
    @IBOutlet weak var collectionViewPhotos: UICollectionView!
    @IBOutlet weak var collectionViewGifts: UICollectionView!
    @IBOutlet weak var collectionViewDescription: UICollectionView!
    @IBOutlet weak var collectionViewSports: UICollectionView!
    @IBOutlet weak var collectionViewTag: UICollectionView!
    @IBOutlet weak var collectionViewTags: UICollectionView!
    @IBOutlet weak var collectionViewMatches: UICollectionView!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show(withStatus: "Loading User Data...")
        SVProgressHUD.setDefaultMaskType(.black)
        
        self.setViewsEstimatedSize();
        
        self.title = "User Detail"
        
        loadFromDB();
        
        if self.userDetail == nil {
            sendRequest();
        } else {
            self.updateScreen();
        }
        
        
        
    }
    
    func loadFromDB() {
        do {
            let fetchRequest: NSFetchRequest<UserProfile> = UserProfile.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", self.userId)
            let userProfiles: [UserProfile] = try context.fetch(fetchRequest)
            
            for user in userProfiles {
                self.userDetail = UserDetail();
                self.userDetail.id = user.id
                self.userDetail.name = user.name
                self.userDetail.mainImage = user.mainImage
                
                for basic in (user.userProfileBasics?.allObjects as? [UserProfileBasics])! {
                    let userDetailBasic = UserDetailValue(title: basic.title!, content: basic.content!);
                    self.userDetail.basicsArr.append(userDetailBasic!)
                }
                
                for desc in (user.userProfileDesc?.allObjects as? [UserProfileDesc])! {
                    let userDetailDesc = UserDetailValue(title: desc.title!, content: desc.content!);
                    self.userDetail.descriptionArr.append(userDetailDesc!)
                }
                
                for match in (user.userProfileMatch?.allObjects as? [UserProfileMatch])! {
                    let userDetailMatch = UserDetailValue(title: match.title!, content: match.content!);
                    self.userDetail.matchArr.append(userDetailMatch!)
                }
                
                for photo in (user.userProfilePhoto?.allObjects as? [UserProfilePhoto])! {
                    let userDetailPhoto = UserDetailPhoto(title: photo.title!, imageUrl: photo.imageUrl!);
                    self.userDetail.photosArr.append(userDetailPhoto!)
                }
                
                for gift in (user.userProfileGift?.allObjects as? [UserProfileGift])! {
                    let userDetailGift = UserDetailPhoto(title: gift.title!, imageUrl: gift.imageUrl!);
                    self.userDetail.giftArr.append(userDetailGift!)
                }
                
                for tag in (user.userProfileTag?.allObjects as? [UserProfileTag])! {
                    let userDetailTag = UserDetailValue(title: tag.title!, content: "");
                    self.userDetail.tagArr.append(userDetailTag!)
                }
                
                for option in (user.userProfileOptions?.allObjects as? [UserProfileOption])! {
                    let userDetailOption = UserDetailValueArr(title: option.title!, content: []);
                    
                    for optionValue in (option.userProfileOptionValues?.allObjects as? [UserProfileOptionValues])! {
                        
                        if option.title! == "Sport" {
                            self.sportsArr.append(optionValue.content!)
                        } else if option.title! == "Tag" {
                            self.tagsArr.append(optionValue.content!)
                        }
                        
                        userDetailOption?.content?.append(optionValue.content!);
                    }
                    
                    self.userDetail.optionArr.append(userDetailOption!)
                }
            }
        
        }
        catch {
            print("Fetching Failed")
        }
    }
    
    func setViewsEstimatedSize() {
      //tutorial round labels https://medium.com/@wasinwiwongsak/uicollectionview-with-autosizing-cell-using-autolayout-in-ios-9-10-84ab5cdf35a2
      if let flowLayoutSports = collectionViewSports.collectionViewLayout as? UICollectionViewFlowLayout {
        flowLayoutSports.estimatedItemSize = CGSize(width: 1, height: 1);
      }
    
      if let flowLayoutTag = collectionViewTag.collectionViewLayout as? UICollectionViewFlowLayout {
        flowLayoutTag.estimatedItemSize = CGSize(width: 1, height: 1);
      }
    
      if let flowLayoutTags = collectionViewTags.collectionViewLayout as? UICollectionViewFlowLayout {
        flowLayoutTags.estimatedItemSize = CGSize(width: 1, height: 1);
      }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func sendRequest() {
        let url = "http://eadate.com/api/userinfo/" + self.userId;
        Alamofire.request(url)
            .responseJSON { (responseData) -> Void in
                
                
                guard let responseJSON = responseData.result.value as? [String: Any],
                    let results = responseJSON["data"] as? [String: Any]
                    else {
                        print("Error");
                        return
                }
                
                
                self.userDetail = Mapper<UserDetail>().map(JSONObject: results)
                
                
                for option in self.userDetail.optionArr {
                    if option.title! == "Sport" {
                        self.sportsArr = option.content!;
                    } else if option.title! == "Tag" {
                        self.tagsArr = option.content!;
                    }
                }
                
                self.saveInDB();
                
                self.updateScreen()
                
        }
        
    }
    
    func saveInDB() {
        
        
        let userProfile = UserProfile(context: self.context);
        userProfile.id = self.userDetail.id
        userProfile.name = self.userDetail.name;
        userProfile.mainImage = self.userDetail.mainImage;
        
        for basic in self.userDetail.basicsArr {
            
            let userBasic = UserProfileBasics(context: self.context);
            userBasic.content = basic.content;
            userBasic.title = basic.title;
            userBasic.userProfileId = self.userDetail.id;
            
            userProfile.addToUserProfileBasics(userBasic)
        }
        
        for desc in self.userDetail.descriptionArr {
            
            let userDesc = UserProfileDesc(context: self.context);
            userDesc.content = desc.content
            userDesc.title = desc.title;
            
            userProfile.addToUserProfileDesc(userDesc)
        }
        
        for match in self.userDetail.matchArr {
            
            let userMatch = UserProfileMatch(context: self.context);
            userMatch.content = match.content
            userMatch.title = match.title;
            
            userProfile.addToUserProfileMatch(userMatch)
        }
        
        for photo in self.userDetail.photosArr {
            
            let userPhoto = UserProfilePhoto(context: self.context);
            userPhoto.imageUrl = photo.imageUrl
            userPhoto.title = photo.title;
            
            userProfile.addToUserProfilePhoto(userPhoto)
        }
        
        for gift in self.userDetail.giftArr {
            
            let userGift = UserProfileGift(context: self.context);
            userGift.imageUrl = gift.imageUrl
            userGift.title = gift.title;
            
            userProfile.addToUserProfileGift(userGift)
        }
        
        for tag in self.userDetail.tagArr {
            
            let userTag = UserProfileTag(context: self.context);
            userTag.content = tag.content
            userTag.title = tag.title;
            
            userProfile.addToUserProfileTag(userTag)
        }
        
        for option in self.userDetail.optionArr {
            let userOption = UserProfileOption(context: self.context)
            userOption.title = option.title
            
            for optionValue in option.content! {
                let userOptionValue = UserProfileOptionValues(context: self.context)
                userOptionValue.content = optionValue
                
                userOption.addToUserProfileOptionValues(userOptionValue)
            }
            
            userProfile.addToUserProfileOptions(userOption)
        }
        
        // Save the data to coredata
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
    }
    
    func updateScreen() {
        SVProgressHUD.dismiss()
        self.title = self.userDetail.name;
        
        //Main Image
        imgMainImage.layer.borderWidth = 2
        imgMainImage.layer.masksToBounds = false
        imgMainImage.layer.borderColor = UIColor.white.cgColor
        imgMainImage.layer.cornerRadius = imgMainImage.frame.height/2
        imgMainImage.clipsToBounds = true
        
        let mainImage = self.userDetail.mainImage
        let mainImageUrl = "http://eadate.com/images/user/" + mainImage! + "_size_80.png"
        let url = URL(string: mainImageUrl)
        imgMainImage.kf.setImage(with: url, completionHandler: nil)
        
        
        //View Basics
        self.collectionViewBasics.reloadData()
        self.collectionViewPhotos.reloadData()
        self.collectionViewGifts.reloadData()
        self.collectionViewDescription.reloadData()
        self.collectionViewSports.reloadData()
        self.collectionViewTag.reloadData()
        self.collectionViewTags.reloadData()
        self.collectionViewMatches.reloadData()

    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.userDetail != nil {
          if collectionView == self.collectionViewBasics {
              return self.userDetail.basicsArr.count
          } else if collectionView == self.collectionViewPhotos {
              return self.userDetail.photosArr.count
          } else if collectionView == self.collectionViewGifts {
            return self.userDetail.giftArr.count
          } else if collectionView == self.collectionViewDescription {
            return self.userDetail.descriptionArr.count
          } else if collectionView == self.collectionViewSports {
            return self.sportsArr.count
          } else if collectionView == self.collectionViewTag {
            return self.tagsArr.count
          } else if collectionView == self.collectionViewTags {
            return self.userDetail.tagArr.count
          } else if collectionView == self.collectionViewMatches {
            return self.userDetail.matchArr.count
          }
        }
        return 0;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "basicsCell", for: indexPath) as! UserDetailBasicCell
        
        if collectionView == self.collectionViewBasics {
            
            cell.lbObject.text = self.userDetail.basicsArr[indexPath.row].title
            cell.lbValue.text = self.userDetail.basicsArr[indexPath.row].content
            
        } else if collectionView == self.collectionViewPhotos {
            
            let pictureName = self.userDetail.photosArr[indexPath.row].imageUrl
            let mainImageUrl = "http://eadate.com/images/user/" + pictureName! + "_size_80.png"
            let url = URL(string: mainImageUrl)
            cell.imgPicture.kf.setImage(with: url, completionHandler: nil)
            
        } else if collectionView == self.collectionViewGifts {
            
            let pictureName = self.userDetail.giftArr[indexPath.row].imageUrl
            let mainImageUrl = "http://eadate.com/images/gift/" + pictureName! + "_size_80.png"
            let url = URL(string: mainImageUrl)
            cell.imgPicture.kf.setImage(with: url, completionHandler: nil)
            
        } else if collectionView == self.collectionViewDescription {
            
            cell.lbObject.text = self.userDetail.descriptionArr[indexPath.row].title
            cell.lbValue.text = self.userDetail.descriptionArr[indexPath.row].content
            
        } else if collectionView == self.collectionViewSports {
            
            cell.lbValue.text = self.sportsArr[indexPath.row]
            cell.layer.cornerRadius = 10
            cell.clipsToBounds = true;
            
        } else if collectionView == self.collectionViewTag {
            
            cell.lbValue.text = self.tagsArr[indexPath.row]
            cell.layer.cornerRadius = 10
            cell.clipsToBounds = true;
            
        } else if collectionView == self.collectionViewTags {
            
            cell.lbValue.text = self.userDetail.tagArr[indexPath.row].title
            cell.layer.cornerRadius = 10
            cell.clipsToBounds = true;
            
        } else if collectionView == self.collectionViewMatches {
            
            cell.lbObject.text = self.userDetail.matchArr[indexPath.row].title
            cell.lbValue.text = self.userDetail.matchArr[indexPath.row].content
            
        }
        
        return cell;
    }
    
}


