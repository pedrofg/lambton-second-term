
import UIKit
import EasyPeasy

class UserDetailsController: UIViewController {
    
    var userId : String!
    
    @IBOutlet weak var txtUserId: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtUserId.text = userId
        
        self.title = "User Detail"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
}


