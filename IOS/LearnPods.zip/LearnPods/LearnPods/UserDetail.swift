//
//  UserInfo.swift
//  LearnPods
//
//  Created by Yao Lu on 2017-07-10.
//  Copyright © 2017 Yao Lu. All rights reserved.
//

import Foundation
import ObjectMapper

class UserDetail: Mappable {
    public var id: String?
    public var name: String?
    public var mainImage: String?
    public var basicsArr: [UserDetailValue] = [];
    public var descriptionArr: [UserDetailValue] = [];
    public var matchArr: [UserDetailValue] = [];
    public var photosArr: [UserDetailPhoto] = [];
    public var giftArr: [UserDetailPhoto] = [];
    public var optionArr: [UserDetailValueArr] = [];
    public var tagArr: [UserDetailValue] = [];
    
    required init?(id: String, name: String, mainImage: String, basicsArr: [UserDetailValue], descriptionArr: [UserDetailValue], matchArr: [UserDetailValue], photosArr: [UserDetailPhoto], giftArr: [UserDetailPhoto], optionArr: [UserDetailValueArr], tagArr: [UserDetailValue]) {
        self.id = id
        self.name = name
        self.mainImage = mainImage
        self.basicsArr = basicsArr
        self.descriptionArr = descriptionArr
        self.matchArr = matchArr
        self.photosArr = photosArr
        self.giftArr = giftArr
        self.optionArr = optionArr
        self.tagArr = tagArr

    }
    
    required init? () {
        
    }
    
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        id                  <- map["id"]
        name                <- map["main.displayName"]
        mainImage           <- map["main.mainImage"]
        basicsArr           <- map["basic"]
        descriptionArr      <- map["description"]
        matchArr            <- map["match"]
        photosArr           <- map["image"]
        giftArr             <- map["gift"]
        optionArr           <- map["option"]
        tagArr              <- map["tag"]
    }
}


class UserDetailValue: Mappable {
    var title: String?
    var content: String?
    
    required init?(title: String, content: String) {
        self.title = title
        self.content = content
    }
    
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        title    <- map["title"]
        content    <- map["content"]
    }
}

class UserDetailValueArr: Mappable {
    var title: String?
    var content: [String]?
    
    required init?(title: String, content: [String]) {
        self.title = title
        self.content = content
    }
    
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        title    <- map["title"]
        content    <- map["content"]
    }
}

class UserDetailPhoto: Mappable {
    var title: String?
    var imageUrl: String?
    
    required init?(title: String, imageUrl: String) {
        self.title = title
        self.imageUrl = imageUrl
    }
    
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        title    <- map["title"]
        imageUrl    <- map["imageUrl"]
    }
}
