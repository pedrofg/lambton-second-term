//
//  User+CoreDataClass.swift
//
//
//  Created by Pedro Guimarães fernandes on 2017-11-19.
//
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData
import ObjectMapper

@objc(User)
public class User: NSManagedObject, Mappable {
    
    
    @NSManaged public var id: String?
    @NSManaged public var name: String?
    @NSManaged public var signature: String?
    @NSManaged public var image: String?
    @NSManaged public var birthday: String?
    
    
    override init(entity: NSEntityDescription, insertIntoManagedObjectContext context: NSManagedObjectContext?) {
        super.init(entity: entity, insertIntoManagedObjectContext: DBUtils().getManagedObjectContext())
    }
    
    required init?(_ map: Map) {
        var ctx = NSManagedObjectContext.MR_defaultContext()
        var entity = NSEntityDescription.entityForName("AbstractModel", inManagedObjectContext: ctx)
        super.init(entity: entity!, insertIntoManagedObjectContext: ctx)
        
        mapping(map)
    }
    
    // Mappable
    func mapping(map: Map) {
        id    <- map["id"]
        displayName    <- map["displayName"]
        signature      <- map["signature"]
        birthday       <- map["birthday"]
        mainImage      <- map["mainImage"]
    }
}


