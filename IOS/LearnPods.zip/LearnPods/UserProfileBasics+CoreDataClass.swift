//
//  UserProfileBasics+CoreDataClass.swift
//  
//
//  Created by Pedro Guimarães fernandes on 2017-11-20.
//
//

import Foundation
import CoreData

@objc(UserProfileBasics)
public class UserProfileBasics: NSManagedObject {

}
