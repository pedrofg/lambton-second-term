//
//  UserProfile+CoreDataProperties.swift
//  
//
//  Created by Pedro Guimarães fernandes on 2017-11-20.
//
//

import Foundation
import CoreData


extension UserProfile {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserProfile> {
        return NSFetchRequest<UserProfile>(entityName: "UserProfile")
    }

    @NSManaged public var id: String?
    @NSManaged public var name: String?
    @NSManaged public var mainImage: String?
    @NSManaged public var relationship: NSSet?

}

// MARK: Generated accessors for relationship
extension UserProfile {

    @objc(addRelationshipObject:)
    @NSManaged public func addToRelationship(_ value: UserProfileBasics)

    @objc(removeRelationshipObject:)
    @NSManaged public func removeFromRelationship(_ value: UserProfileBasics)

    @objc(addRelationship:)
    @NSManaged public func addToRelationship(_ values: NSSet)

    @objc(removeRelationship:)
    @NSManaged public func removeFromRelationship(_ values: NSSet)

}
