//
//  UserProfile+CoreDataClass.swift
//  
//
//  Created by Pedro Guimarães fernandes on 2017-11-20.
//
//

import Foundation
import CoreData

@objc(UserProfile)
public class UserProfile: NSManagedObject {

}
