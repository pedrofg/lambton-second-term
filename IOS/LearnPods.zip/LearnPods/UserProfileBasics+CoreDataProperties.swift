//
//  UserProfileBasics+CoreDataProperties.swift
//  
//
//  Created by Pedro Guimarães fernandes on 2017-11-20.
//
//

import Foundation
import CoreData


extension UserProfileBasics {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserProfileBasics> {
        return NSFetchRequest<UserProfileBasics>(entityName: "UserProfileBasics")
    }

    @NSManaged public var userProfileId: String?
    @NSManaged public var title: String?
    @NSManaged public var content: String?
    @NSManaged public var relationship: UserProfile?

}
