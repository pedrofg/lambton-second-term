//
//  ViewController.swift
//  FinalTest
//
//  Created by Pedro Guimarães fernandes on 2017-11-23.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UITableViewController {

    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var users : [User] = [];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Users"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadFromDB();
    }
    
    func loadFromDB() {
        do {
            
            self.users = try context.fetch(User.fetchRequest())
            self.tableView.reloadData();
            print(self.users)
        }
        catch {
            print("Fetching Failed")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func addBtnClicked(_ sender: Any) {
        print("Add button clicked")
        let addUserController = self.storyboard!.instantiateViewController(withIdentifier: "AddViewController") as! AddViewController
        navigationController?.pushViewController(addUserController, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let addUserController = self.storyboard!.instantiateViewController(withIdentifier: "AddViewController") as! AddViewController
        addUserController.user = users[indexPath.row];
        navigationController?.pushViewController(addUserController, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.users.count;
    }
//    
//    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 110.0;
//    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
        let name = users[indexPath.row].name!
        let age = users[indexPath.row].age
        let major = users[indexPath.row].major!
        
        cell.lbName.text = name
        cell.lbAge.text = "\(age)"
        cell.lbMajor.text = major
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            
            
            do {
                let user = users[indexPath.row];
                context.delete(user);
                self.users.remove(at: indexPath.row)
                
                try context.save()
                self.tableView.reloadData();
                
                
            }
            catch {
                print("Fetching Failed")
            }

        }
    }
    
    func deleteUserClick(sender: UIButton!) {
        

    }
    
    


}

