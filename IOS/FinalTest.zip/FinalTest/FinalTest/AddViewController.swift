//
//  AddViewController.swift
//  FinalTest
//
//  Created by Pedro Guimarães fernandes on 2017-11-23.
//  Copyright © 2017 Pedro Fernandes. All rights reserved.
//

import UIKit

class AddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var sliderAge: UISlider!
    @IBOutlet weak var majorDatePicker: UIPickerView!
    var selectedMajor: String = ""
    var ageValue: Int = 20;
    var pickerData = ["Math","Science","Computing","Biology","Chemestry"]
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var user: User?
    
    @IBOutlet weak var lbSliderValue: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.majorDatePicker.delegate = self
        self.majorDatePicker.dataSource = self
        
        if user != nil {
            self.tfName.text = user?.name
            let age = user?.age;
            self.sliderAge.value = Float((user?.age)!)
            self.lbSliderValue.text = "\(age!)"
            
            let index = pickerData.index(of: user!.major!);
            self.selectedMajor = (user?.major)!;
            self.majorDatePicker.selectRow(index!, inComponent: 0, animated: false)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnConfirmClick(_ sender: Any) {
        let name = self.tfName.text;
        let age = Int16(self.ageValue)
        
        if self.user != nil {
            self.user?.name = name;
            self.user?.age = age
            self.user?.major = self.selectedMajor
        } else {
            let user = User(context: self.context)
            user.name = name
            user.age = age
            user.major = self.selectedMajor
            user.id = randomString(length: 10);
        }
        
        
        
        // Save the data to coredata
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
        navigationController?.popViewController(animated: true);
    }
    
    @IBAction func sliderChange(_ sender: UISlider) {
        self.ageValue = Int(sender.value)
        self.lbSliderValue.text = "\(self.ageValue)";
    }
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    @available(iOS 2.0, *)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    // Catpure the picker view selection
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.selectedMajor = pickerData[row]
    }
    
    func randomString(length: Int) -> String {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let len = UInt32(letters.length)
        
        var randomString = ""
        
        for _ in 0 ..< length {
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        
        return randomString
    }


}
