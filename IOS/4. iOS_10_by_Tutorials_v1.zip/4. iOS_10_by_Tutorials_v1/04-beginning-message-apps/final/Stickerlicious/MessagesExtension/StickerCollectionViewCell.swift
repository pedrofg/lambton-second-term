//
//  StickerCollectionViewCell.swift
//  Stickerlicious
//
//  Created by Richard Turton on 04/07/2016.
//  Copyright © 2016 Razeware. All rights reserved.
//

import UIKit
import Messages

class StickerCollectionViewCell: UICollectionViewCell {
  
  @IBOutlet weak var stickerView: MSStickerView!
  
}
